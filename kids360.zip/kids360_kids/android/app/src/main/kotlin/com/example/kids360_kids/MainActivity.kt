package com.example.kids360_kids

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
