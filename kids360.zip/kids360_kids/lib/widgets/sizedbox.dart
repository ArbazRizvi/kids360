import 'package:flutter/material.dart';

Widget sizedBox(double height, double width) {
  return SizedBox(
    height: height,
    width: width,
  );
}
